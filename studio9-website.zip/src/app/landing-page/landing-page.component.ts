import { Component, OnInit, HostListener, ChangeDetectorRef, AfterViewChecked } from '@angular/core';
import { OwlOptions } from 'ngx-owl-carousel-o';
import Typed from 'typed.js';
import SmoothScroll from 'smooth-scroll';
import * as $ from 'jquery';

@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.less']
})
export class LandingPageComponent implements OnInit, AfterViewChecked {

  customOptions: OwlOptions = {
    items: 2,
    margin: 0,
    center: true,
    loop: true,
    stagePadding: 0,
    autoplay: false,
    autoWidth: true,
    nav: true,
    autoplayTimeout: 5000,
    autoplayHoverPause: true,
    smartSpeed: 1000
  };
  preweddingPhotos: string[] = ['sample.jpg', 'sample.jpg', 'sample.jpg',
  'sample.jpg', 'sample.jpg', 'sample.jpg'];

  weddingPhotos: string[] = ['sample.jpg', 'sample.jpg', 'sample.jpg', 'sample.jpg',
  'sample.jpg', 'sample.jpg', 'sample.jpg'];

  services = [
    {
      img: 'srv1.jpg',
      title: 'Wedding Photogrpahy',
      descr: `We provide complete wedding photography and video
      shooting using latest technology and drone`
    },
    {
      img: 'srv2.jpg',
      title: 'Wedding Photogrpahy',
      descr: `We provide complete wedding photography and video
      shooting using latest technology and drone`
    },
    {
      img: 'srv3.jpg',
      title: 'Wedding Photogrpahy',
      descr: `We provide complete wedding photography and video
      shooting using latest technology and drone`
    },
    {
      img: 'srv4.jpg',
      title: 'Wedding Photogrpahy',
      descr: `We provide complete wedding photography and video
      shooting using latest technology and drone`
    },
    {
      img: 'srv5.jpg',
      title: 'Wedding Photogrpahy',
      descr: `We provide complete wedding photography and video
      shooting using latest technology and drone`
    },
    {
      img: 'srv6.jpg',
      title: 'Wedding Photogrpahy',
      descr: `We provide complete wedding photography and video
      shooting using latest technology and drone`
    },
    {
      img: 'srv7.jpg',
      title: 'Wedding Photogrpahy',
      descr: `We provide complete wedding photography and video
      shooting using latest technology and drone`
    }
  ];

  ourteam = [
    {
      img: 'founder_1.jpg',
      name: 'Akash Dhore',
      designation: 'CEO & Founder',
      fbLink: '',
      igLink: '',
      twLink: ''
    },
    {
      img: 'founder_2.jpg',
      name: 'Pralhad Kalokhe',
      designation: 'Founder',
      fbLink: '',
      igLink: '',
      twLink: ''
    },
    {
      img: 'editor_1.jpg',
      name: 'Sarthak Pandey',
      designation: 'Photo Editor',
      fbLink: '',
      igLink: '',
      twLink: ''
    },
    {
      img: 'editor_2.jpg',
      name: 'Yadnesh Pathak',
      designation: 'Video Editor',
      fbLink: '',
      igLink: '',
      twLink: ''
    }
  ];

  skills = [
    {
    title: 'Adobe Photoshop CS6',
    percent: 95,
    color: '#ffc046'
  },
  {
    title: 'Adobe After Effects',
    percent: 85,
    color: '#5efc82'
  },
  {
    title: 'Lightroom',
    percent: 81,
    color: '#9a67ea'
  },
  {
    title: 'Adobe illustrator',
    percent: 83,
    color: '#718792'
  },
  {
    title: 'Adobe Premier Pro',
    percent: 92,
    color: '#ff867f'
  }
];

instafeeds = [
  'cr1.jpg',
  'cr2.jpg',
  'cr3.jpg',
  'cr4.jpg',
  'cr5.jpg',
  'cr6.jpg'
]

  constructor(private changeDetector : ChangeDetectorRef) { }

  ngOnInit() {
  }
  
  ngAfterViewChecked(){
    this.changeDetector.detectChanges();
  }

  getBackground() {
    return '#' + Math.floor(Math.random()*16777215).toString(16);
  }
}
