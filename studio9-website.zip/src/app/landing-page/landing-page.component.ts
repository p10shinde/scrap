import { Component, OnInit, HostListener } from '@angular/core';
import { OwlOptions } from 'ngx-owl-carousel-o';
import Typed from 'typed.js';
import SmoothScroll from 'smooth-scroll';
import * as $ from 'jquery';

@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.less']
})
export class LandingPageComponent implements OnInit {

  customOptions: OwlOptions = {
    items: 2,
    margin: 0,
    center: true,
    loop: true,
    stagePadding: 0,
    autoplay: false,
    autoWidth: true,
    nav: true,
    autoplayTimeout: 5000,
    autoplayHoverPause: true,
    smartSpeed: 1000
  };
  preweddingPhotos: string[] = ['cr1.jpg', 'cr2.jpg', 'cr3.jpg',
  'cr4.jpg', 'cr5.jpg', 'cr6.jpg'];

  weddingPhotos: string[] = ['cr5.jpg', 'cr6.jpg', 'cr7.jpg', 'cr8.jpg',
  'cr9.jpg', 'cr19.jpg', 'cr24.jpg'];

  constructor() { }

  ngOnInit() {
  }
}
