import { Component, OnInit, HostListener } from '@angular/core';
import Typed from 'typed.js';
import SmoothScroll from 'smooth-scroll';
import * as $ from 'jquery';
import AOS from 'aos';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.less']
})
export class AppComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    AOS.init();
  }
}
