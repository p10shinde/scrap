import { Component, OnInit } from '@angular/core';
import { GoogleLoginProvider } from 'angularx-social-login';
import { AuthService } from 'angularx-social-login';
import { SocialUser } from "angularx-social-login";
import AOS from 'aos';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.less']
})
export class LoginComponent implements OnInit {

  
  private isError: boolean = false;
  private errorText: String = 'Something went wrong. Please try again.'

  constructor(
    private authService: AuthService
    ) { }

  ngOnInit() {
    AOS.init({
      duration: 800,
      easing: 'slide',
      once: true
    });
    
  }

  signInWithGoogle(): void {
    this.authService.signIn(GoogleLoginProvider.PROVIDER_ID).then(user => {
      console.log(user)
    }).catch(err => {
      console.log(err)
      this.errorText = err;
      this.isError = true;
      setTimeout(() => {
        this.isError = false;
      },10000)
    });
  }

}
