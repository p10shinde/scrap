import { Component, OnInit } from '@angular/core';
import { AuthService } from 'angularx-social-login';
import { SocialUser } from "angularx-social-login";
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.less']
})
export class HeaderComponent implements OnInit {

  private user: SocialUser = null;
  private loggedIn: boolean = false;

  constructor(
    private authService: AuthService,
    private router: Router
  ) { }

  ngOnInit() {
    this.authService.authState.subscribe((user) => {
      this.user = user;
      this.loggedIn = (user != null);
      if (this.loggedIn === true) {
        this.router.navigateByUrl('/');
      }
    });
    
  }

  signOut(): void {
    this.authService.signOut().then(user => {
      console.log(user)
    }).catch(err => {
      console.log(err)
    });
  }

}
